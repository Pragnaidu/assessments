1.	Select passname from passenger where passname like '_e%'	

3.	Select passname,passdob,floor(datediff(day, passdob, getdate()) / 365.25) from passenger;

4.	Select count(*) no_of_flights from flight where flightsource='kol'

6.	Select flightsource from flight where flightsource not in (select flightdest from flight);

7.	Select flightdate from flight where flightid=1 or flightid=4;

8.	Select flightid,count(b.passid) passcount from booking_details b inner join booking d on b.bookingid=d.bookingid group by flightid;

9.	Select passname,passdob,floor(datediff(day, passdob, getdate()) / 365.25)as age from passenger where floor(datediff(day, passdob, getdate()) / 365.25)>=60;	

11.	Select b.bookingid,f.ticketcost total_fare from booking b inner join flight f on b.flightid=f.flightid

12.	Select flightdest from flight group by flightdest having count(*)=(select max(c) from (select count(*) c from flight group by flightdest)a);

13.	Select passname from passenger where passid in (select passid from booking_details group by passid having count(bookingid)>1);

14.	Select flightid,count(*) no_of_bookings from booking group by flightid;
